document.addEventListener('DOMContentLoaded', () => {
    const addRecipeBtn = document.getElementById('add-recipe-btn');
    const recipeTitleInput = document.getElementById('recipe-title');
    const recipeIngredientsInput = document.getElementById('recipe-ingredients');
    const recipeStepsInput = document.getElementById('recipe-steps');
    const recipeImageUrlInput = document.getElementById('recipe-image-url');
    const recipeList = document.getElementById('recipe-list');

    // Function to add a new recipe
    const addRecipe = () => {
        const title = recipeTitleInput.value.trim();
        const ingredients = recipeIngredientsInput.value.trim();
        const steps = recipeStepsInput.value.trim();
        const imageUrl = recipeImageUrlInput.value.trim();

        if (title === '' || ingredients === '' || steps === '') return;

        const listItem = document.createElement('li');

        const titleElem = document.createElement('h2');
        titleElem.textContent = title;

        const ingredientsElem = document.createElement('p');
        ingredientsElem.innerHTML = `<strong>Ingredients:</strong> ${ingredients.split(',').join(', ')}`;

        const stepsElem = document.createElement('p');
        stepsElem.innerHTML = `<strong>Steps:</strong> ${steps}`;

        if (imageUrl) {
            const imageElem = document.createElement('img');
            imageElem.src = imageUrl;
            listItem.appendChild(imageElem);
        }

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.classList.add('delete-btn');
        deleteBtn.addEventListener('click', () => {
            recipeList.removeChild(listItem);
        });

        listItem.appendChild(titleElem);
        listItem.appendChild(ingredientsElem);
        listItem.appendChild(stepsElem);
        listItem.appendChild(deleteBtn);
        recipeList.appendChild(listItem);

        recipeTitleInput.value = '';
        recipeIngredientsInput.value = '';
        recipeStepsInput.value = '';
        recipeImageUrlInput.value = '';
    };

    // Add recipe on button click
    addRecipeBtn.addEventListener('click', addRecipe);

    // Optional: Add recipe on pressing 'Enter'
    recipeTitleInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addRecipe();
        }
    });

    recipeIngredientsInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addRecipe();
        }
    });

    recipeStepsInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addRecipe();
        }
    });

    recipeImageUrlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            addRecipe();
        }
    });
});